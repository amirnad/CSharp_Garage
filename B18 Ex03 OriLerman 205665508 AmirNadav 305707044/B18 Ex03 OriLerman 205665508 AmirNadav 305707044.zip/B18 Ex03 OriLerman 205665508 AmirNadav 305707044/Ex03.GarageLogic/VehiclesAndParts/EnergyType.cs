﻿namespace Ex03.GarageLogic
{
    public abstract class EnergyType
    {
        public abstract void CalculateRatio();
    }
}